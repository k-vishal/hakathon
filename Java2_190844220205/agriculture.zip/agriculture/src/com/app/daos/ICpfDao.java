package com.app.daos;

public interface ICpfDao {

}
