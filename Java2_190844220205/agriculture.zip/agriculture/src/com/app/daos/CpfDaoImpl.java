package com.app.daos;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CpfDaoImpl implements ICpfDao {

	@Autowired 
	private SessionFactory sf;
}
