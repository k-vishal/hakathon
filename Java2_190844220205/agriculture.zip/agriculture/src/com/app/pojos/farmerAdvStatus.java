package com.app.pojos;

public enum farmerAdvStatus {
	PENDING, APPROVED, CLOSED, CANCELLED
}
