package com.app.pojos;

public enum UserStatus {
	ADMIN,ACTIVE,BLOCKED
}
